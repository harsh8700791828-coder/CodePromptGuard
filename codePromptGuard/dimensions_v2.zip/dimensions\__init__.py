"""Prompt health scoring dimensions."""
